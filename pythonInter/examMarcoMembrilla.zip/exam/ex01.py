# Se piden los datos al usuario
# Se parsean los input a enteros
a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))

# Se calcula c, ** significa potenciar
c = (a ** 2 + b ** 2) ** 0.5

# Se muestra el resultado
print(f"The answer is {c}")