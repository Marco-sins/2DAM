# Funcion que calcula la superficie

def superficie():
    side = float(input("Introduce los lados del cuadrado: "))
    superficie = side * side
    print(f"El area del cuadrado es {superficie}")

superficie()